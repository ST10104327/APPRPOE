﻿using DonationAppl.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using static DonationAppl.Models.Disaster;

namespace DonationAppl.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
   

    public DbSet<GoodsDonation> GoodsDonations { get; set; }
        public DbSet<GoodsCategory> GoodsCategories { get; set; }

        // Add other DbSets as needed

        // Configure your existing models and other settings...

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships, constraints, etc.

            // Seed initial categories
            modelBuilder.Entity<GoodsCategory>().HasData(
                new GoodsCategory { GoodsCategoryId = 1, Name = "Clothes" },
                new GoodsCategory { GoodsCategoryId = 2, Name = "Non-perishable foods" }); }
         
            public DbSet<Disaster> Disasters { get; set; }
            public DbSet<AidType> AidTypes { get; set; }
        public object Notifications { get; internal set; }
        public object GoodsAllocations { get; internal set; }
        public object GoodsPurchases { get; internal set; }

        // ... Other configurations

        protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                // ... Other configurations

                modelBuilder.Entity<Disaster>()
                    .HasMany(d => d.RequiredAidTypes)
                    .WithMany()
                    .UsingEntity(j => j.ToTable("DisasterAidTypes"));
            }
        }


    }


