﻿using Microsoft.AspNetCore.Mvc;
using DonationAppl.Data;
using DonationAppl.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using Microsoft.AspNetCore.Authorization;

namespace DonationAppl.Controllers
{
   

    public class GoodsAllocationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GoodsAllocationController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Action to display the form for goods allocation
        public IActionResult Allocate()
        {
            // Retrieve active disasters and pass them to the view
            var activeDisasters = _context.Disasters
                .Where(d => d.StartDate <= DateTime.Now && d.EndDate >= DateTime.Now)
                .ToList();

            return View(activeDisasters);
        }

        // Action to process the goods allocation
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Allocate(GoodsAllocationViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check authorization and budget, then update the database with the goods allocation

                // Create a GoodsAllocation entity and save it to the database
                var goodsAllocation = new GoodsAllocation
                {
                    GoodsType = model.GoodsType,
                    Quantity = model.Quantity,
                    AllocationDate = DateTime.Now,
                    DisasterId = model.DisasterId,
                    Status = "Pending", // You can set the initial status
                };

                _context.GoodsAllocations.Add(goodsAllocation);
                _context.SaveChanges();

                // Redirect to a confirmation page or display a success message
            }

            // If the model is not valid, redisplay the form with validation errors
            var activeDisasters = _context.Disasters
                .Where(d => d.StartDate <= DateTime.Now && d.EndDate >= DateTime.Now)
                .ToList();

            return View(activeDisasters);
        }

        // Action to view goods allocation details
        public IActionResult Details(int id)
        {
            var goodsAllocation = _context.GoodsAllocations
                .Include(g => g.Disaster)
                .FirstOrDefault(g => g.Id == id);

            if (goodsAllocation == null)
            {
                return NotFound();
            }

            return View(goodsAllocation);
        }

        // Action to manage the allocation status (e.g., approve, reject)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ManageStatus(int id, string status)
        {
            var goodsAllocation = _context.GoodsAllocations.Find(id);

            if (goodsAllocation == null)
            {
                return NotFound();
            }

            // Update the goods allocation status based on the provided status (approve, reject, etc.)

            // Save changes to the database

            // Redirect to the appropriate view or action
        }
        [Authorize]
      

            // Action to process the goods allocation
            [HttpPost]
            [ValidateAntiForgeryToken]
        public IActionResult Allocate(GoodsAllocationViewModel model)
            {
                if (ModelState.IsValid)
                {
                    // Check authorization and budget, then update the database with the goods allocation
                    if (IsAuthorizedToAllocateGoods(User.Identity.Name)) // Implement your custom authorization logic
                    {
                        // ...

                        // Create a GoodsAllocation entity and save it to the database
                        var goodsAllocation = new GoodsAllocation
                        {
                            // Properties
                        };

                    _context.GoodsAllocations.Add(goodsAllocation);
                        _context.SaveChanges();

                        // Redirect to a confirmation page or display a success message
                    }
                    else
                    {
                        return Forbid(); // Return a 403 Forbidden response if the user is not authorized
                    }
                }

                // If the model is not valid, redisplay the form with validation errors
                // ...
            }

        // ...

        // Custom authorization logic to check if the user is authorized to allocate goods
        private bool IsAuthorizedToAllocateGoods(string userName)
            {
                // Implement your custom authorization logic here
                // You can check roles, permissions, or any other criteria
                // Return true if the user is authorized, otherwise return false
            }
        }

    }

    public class GoodsAllocationViewModel
    {
        public string GoodsType { get; internal set; }
        public int Quantity { get; internal set; }
        public int DisasterId { get; internal set; }
    }