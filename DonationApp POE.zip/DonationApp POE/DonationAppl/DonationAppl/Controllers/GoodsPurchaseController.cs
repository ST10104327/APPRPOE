﻿using Microsoft.AspNetCore.Mvc;
using DonationAppl.Data;
using DonationAppl.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using Microsoft.AspNetCore.Authorization;

namespace DonationAppl.Controllers
{


    public class GoodsPurchaseController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GoodsPurchaseController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Action to display the form for capturing goods purchases
        public IActionResult CaptureGoodsPurchase()
        {
            // Retrieve available disasters and pass them to the view
            var availableDisasters = _context.Disasters.ToList();

            return View(availableDisasters);
        }

        // Action to process the goods purchase
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CaptureGoodsPurchase(GoodsPurchaseViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check authorization and budget, then update the database with the goods purchase
                if (IsAuthorizedToCaptureGoodsPurchase(User.Identity.Name)) // Implement your custom authorization logic
                {
                    // ...

                    // Create a GoodsPurchase entity and save it to the database
                    var goodsPurchase = new GoodsPurchase
                    {
                        GoodsType = model.GoodsType,
                        Quantity = model.Quantity,
                        PurchaseDate = DateTime.Now,
                        DisasterId = model.DisasterId,
                        Status = "Purchased", // Set the initial status
                    };

                    _context.GoodsPurchases.Add(goodsPurchase);
                    _context.SaveChanges();

                    // Redirect to a confirmation page or display a success message
                }
                else
                {
                    return Forbid(); // Return a 403 Forbidden response if the user is not authorized
                }
            }

            // If the model is not valid, redisplay the form with validation errors
            var availableDisasters = _context.Disasters.ToList();

            return View(availableDisasters);
        }

        // Action to view goods purchase details
        public IActionResult Details(int id)
        {
            var goodsPurchase = _context.GoodsPurchases
                .Include(p => p.Disaster)
                .FirstOrDefault(p => p.Id == id);

            if (goodsPurchase == null)
            {
                return NotFound();
            }

            return View(goodsPurchase);
        }

        // Action to manage the purchase status (e.g., delivered)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ManageStatus(int id, string status)
        {
            var goodsPurchase = _context.GoodsPurchases.Find(id);

            if (goodsPurchase == null)
            {
                return NotFound();
            }

            // Update the goods purchase status based on the provided status (e.g., delivered).

            // Save changes to the database.

            // Redirect to the appropriate view or action.
        }

        // Custom authorization logic to check if the user is authorized to capture goods purchases
        private bool IsAuthorizedToCaptureGoodsPurchase(string userName)
        {
            // Implement your custom authorization logic here
            // You can check roles, permissions, or any other criteria
            // Return true if the user is authorized, otherwise return false
        }
    }
    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize]
    public IActionResult CaptureGoodsPurchase(GoodsPurchaseViewModel model)
    {
        if (ModelState.IsValid)
        {
            var disaster = _context.Disasters.Find(model.DisasterId);

            // Check if the user is authorized to capture goods purchases.
            if (IsAuthorizedToCaptureGoodsPurchases(User.Identity.Name))
            {
                // Check if the purchase quantity is within the available money budget.
                if (model.Quantity * model.UnitPrice <= disaster.AvailableMoneyBudget)
                {
                    // Create a GoodsPurchase entity and save it to the database.
                    var purchase = new GoodsPurchase
                    {
                        GoodsType = model.GoodsType,
                        Quantity = model.Quantity,
                        PurchaseDate = DateTime.Now,
                        Status = "Purchased", // Set the initial status
                        DisasterId = model.DisasterId,
                    };

                    _context.GoodsPurchases.Add(purchase);

                    // Update the available money budget.
                    disaster.AvailableMoneyBudget -= model.Quantity * model.UnitPrice;

                    // Update the goods inventory for the specified disaster.
                    disaster.AvailableGoodsBudget += model.Quantity;

                    _context.SaveChanges();

                    // Redirect to a confirmation page or display a success message.
                }
                else
                {
                    ModelState.AddModelError("Quantity", "Purchase quantity exceeds the available money budget.");
                }
            }
            else
            {
                return Forbid(); // Return a 403 Forbidden response if the user is not authorized.
            }
        }

        // If the model is not valid, redisplay the form with validation errors.
        // ...
    }
}

