﻿using DonationAppl.Data;
using DonationAppl.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DonationAppl.Controllers
{
    [Authorize]
    public class GoodsDonationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GoodsDonationController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Create()
        {
            // Display goods donation creation form
            return View();
        }

        [HttpPost]
        public IActionResult Create(GoodsDonation goodsDonation)
        {
            if (ModelState.IsValid)
            {
                // Save the goods donation to the database
                _context.GoodsDonations.Add(goodsDonation);
                _context.SaveChanges();

                return RedirectToAction("Index", "Home"); // Redirect to home or another page
            }

            return View(goodsDonation);
        }

        public IActionResult Index()
        {
            var goodsDonations = _context.GoodsDonations.ToList();
            return View(goodsDonations);
        }
    }
}
