﻿using System.ComponentModel.DataAnnotations;
using System.Security.AccessControl;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace DonationAppl.Models
{
    public class Disaster
    {
    
            public int DisasterId { get; set; }
            
            public DateTime EndDate { get; set; }
            public string Location { get; set; }
            public string Description { get; set; }
            public List<AidType> RequiredAidTypes { get; set; }
        public virtual ICollection<GoodsAllocation> GoodsAllocations { get; set; }

        public int Id { get; set; }

            [Required]
            [StringLength(100)]
            public string Name { get; set; }


            [Required]
            [DataType(DataType.Date)]
            [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
            public DateTime StartDate { get; set; }

            [Required]
            [DataType(DataType.Date)]
            [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
            

            [Range(0, double.MaxValue, ErrorMessage = "Budget must be non-negative.")]
            public decimal Budget { get; set; }

            // Navigation property for the related allocations
            public virtual ICollection<Allocation> Allocations { get; set; }
        }

    }

    public class AidType
        {
            public int AidTypeId { get; set; }
            public string Name { get; set; }
        }
    