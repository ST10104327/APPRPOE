﻿namespace DonationAppl.Models
{
    public class GoodsPurchase
    {
        public int Id { get; set; }
        public string GoodsType { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string Status { get; set; } // e.g., "Purchased," "Delivered"

        public int DisasterId { get; set; }
        public Disaster Disaster { get; set; }

        // Add other properties as needed
    }
}