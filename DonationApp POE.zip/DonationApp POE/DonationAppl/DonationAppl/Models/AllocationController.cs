﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DonationAppl.Models
{
    public class AllocationController : Controller
    {
     
        [Authorize(Roles = "Admin")]
        public class AdminController : Controller
        {
            // Only users with the "Admin" role can access actions in this controller.
        }

    }
    [Authorize(Policy = "CustomPolicy")]
    public class CustomController : Controller
    {
        // Users who meet the requirements of "CustomPolicy" can access actions in this controller.
    }

}
    
