﻿using DonationAppl.Models;
using Microsoft.AspNetCore.Mvc;

namespace DonationAppl.Controllers
{
    public interface IDonationController
    {
        IActionResult Create();
        IActionResult Create(Donation donation);
    }
}