﻿using DonationAppl.Data;
using DonationAppl.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DonationAppl.Controllers
{
    public class AllocationController : Controller
    {


        private readonly ApplicationDbContext _context;

        public AllocationController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Allocate()
        {
            var disasters = _context.Disasters
                .Where(d => d.StartDate <= DateTime.Now && d.EndDate >= DateTime.Now)
                .ToList();

            var model = new Allocation
            {
                Disasters = new SelectList(disasters, "Id", "Name"),
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Allocate(Allocation model)
        {
            if (ModelState.IsValid)
            {
                // Check if the user is authorized to allocate funds and if the allocation amount is within budget.

                // Update the database with the allocation data.

                // Redirect to a confirmation page or display a success message.
            }

            // If the model is not valid, redisplay the form with validation errors.
            var disasters = _context.Disasters
                .Where(d => d.StartDate <= DateTime.Now && d.EndDate >= DateTime.Now)
                .ToList();
            model.Disasters = new SelectList(disasters, "Id", "Name");
            return View(model);
        }
        public IActionResult Allocation(AllocationViewModel model)
        {
            // Check if the user is authorized to allocate funds.
            if (!User.IsInRole("AuthorizedRole"))
            {
                return Forbid(); // Return a 403 Forbidden response if the user is not authorized.
            }


        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public IActionResult Allocate(AllocationViewModel model)
        {
            // Check if the user is authorized to allocate funds.
            if (!User.IsInRole("AuthorizedRole"))
            {
                return Forbid();
            }

            // Retrieve the selected disaster from the database.
            var disaster = _context.Disasters.Find(model.DisasterId);

            // Check if the allocation amount is within the available budget.
            if (model.Amount > disaster.Budget)
            {
                ModelState.AddModelError("Amount", "Allocation amount exceeds the available budget.");
            }

            // ...
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public IActionResult Approve(int allocationId)
        {
            // Update the allocation status to "Approved."

            var allocation = _context.Allocation.Find(allocationId);
            allocation.Status = "Approved";

            // Create a notification for the user
            var notification = new Notification
            {
                Message = "Your allocation has been approved.",
                UserId = allocation.UserId,
                Timestamp = DateTime.Now,
                AllocationId = allocationId,
            };

            _context.Notification.Add(notification);

            // Save changes to the database
            _context.SaveChanges();

            // Redirect or return a response
        }


        public class AllocationViewModel
        {
            public object?[]? DisasterId { get; internal set; }
            public decimal Amount { get; internal set; }
        }
    }
}
