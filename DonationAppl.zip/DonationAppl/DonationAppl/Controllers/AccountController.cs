﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using DonationAppl.Models;
using Microsoft.AspNetCore.Authorization;

namespace DonationAppl.Controllers
{
    [Route("[controller]/[action]")]
  

    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(LoginView model, string returnUrl = null)
        {
            // Handle login logic using UserManager and SignInManager
            // Redirect to the appropriate page after login
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Register(RegisterModel model)
        {
            // Handle registration logic using UserManager
            // Redirect to the appropriate page after registration
        }
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        // Redirect to the appropriate page after logout
    }
}


    