﻿namespace DonationAppl.Controllers
{
    public class GoodsPurchaseViewModel
    {
        public string GoodsType { get; internal set; }
        public int Quantity { get; internal set; }
        public int DisasterId { get; internal set; }
    }
}