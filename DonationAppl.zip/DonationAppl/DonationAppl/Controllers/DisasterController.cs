﻿using DonationAppl.Data;
using DonationAppl.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DonationAppl.Controllers
{
    [Authorize]
    public class DisasterController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DisasterController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.AidTypes = _context.AidTypes.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Create(Disaster disaster)
        {
            if (ModelState.IsValid)
            {
                // Save the disaster to the database
                _context.Disasters.Add(disaster);
                _context.SaveChanges();

                return RedirectToAction("Index", "Home"); // Redirect to home or another page
            }

            ViewBag.AidTypes = _context.AidTypes.ToList();
            return View(disaster);
        }

        public IActionResult Index()
        {
            var activeDisasters = _context.Disasters
            .Where(d => d.StartDate <= DateTime.Now && d.EndDate >= DateTime.Now)
            .ToList();

            return View(activeDisasters);
        }

        public IActionResult AllDisasters()
        {
            var disasters = _context.Disasters.Include(d => d.RequiredAidTypes).ToList();
            return View(disasters);
        }

        // Add actions for managing aid types (e.g., CreateAidType, EditAidType)
    }
}