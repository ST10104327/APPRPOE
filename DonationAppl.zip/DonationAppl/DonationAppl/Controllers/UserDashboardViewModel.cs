﻿namespace DonationAppl.Controllers
{
    internal class UserDashboardViewModel
    {
        public object MoneyAllocations { get; set; }
        public object GoodsAllocations { get; set; }
    }
}