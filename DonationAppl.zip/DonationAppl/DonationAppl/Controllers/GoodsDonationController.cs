﻿using DonationAppl.Data;
using DonationAppl.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DonationAppl.Controllers
{
    [Authorize]
    public class GoodsDonationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GoodsDonationController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Categories = _context.GoodsCategories.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Create(GoodsDonation goodsDonation)
        {
            if (ModelState.IsValid)
            {
                // Save the goods donation to the database
                _context.GoodsDonations.Add(goodsDonation);
                _context.SaveChanges();

                return RedirectToAction("Index", "Home"); // Redirect to home or another page
            }

            ViewBag.Categories = _context.GoodsCategories.ToList();
            return View(goodsDonation);
        }

        public IActionResult Index()
        {
            var goodsDonations = _context.GoodsDonations.Include(d => d.GoodsCategory).ToList();
            return View(goodsDonations);
        }

    }
    }
