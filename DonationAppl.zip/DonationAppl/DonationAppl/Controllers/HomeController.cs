﻿using DonationAppl.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Security.Claims;

namespace DonationAppl.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private object _context;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [Authorize]
        public IActionResult UserDashboard()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Get the user's ID

            // Fetch the user's allocation history
            var allocations = _context.Allocations
                .Where(a => a.UserId == userId)
                .Include(a => a.Disaster) // Include Disaster navigation property
                .ToList();

            return View(allocations);
        }
        [Authorize]
        public IActionResult UserDashboard()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Get the user's ID

            // Fetch the user's money allocation history
            var moneyAllocations = _context.MoneyAllocations
                .Where(a => a.UserId == userId)
                .Include(a => a.Disaster)
                .ToList();

            // Fetch the user's goods allocation history
            var goodsAllocations = _context.GoodsAllocations
                .Where(a => a.UserId == userId)
                .Include(a => a.Disaster)
                .ToList();

            return View(new UserDashboardViewModel
            {
                MoneyAllocations = moneyAllocations,
                GoodsAllocations = goodsAllocations
            });
        }

    }
}