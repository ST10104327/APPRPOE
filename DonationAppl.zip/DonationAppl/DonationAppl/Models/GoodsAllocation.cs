﻿namespace DonationAppl.Models
{
    public class GoodsAllocation
    {
        public int Id { get; set; }
        public string GoodsType { get; set; }
        public int Quantity { get; set; }
        public DateTime AllocationDate { get; set; }
        public string Status { get; set; }  // e.g., "Pending," "Approved," "Rejected"

        public int DisasterId { get; set; }
        public Disaster Disaster { get; set; }

        // Add other properties as needed
    }
}
