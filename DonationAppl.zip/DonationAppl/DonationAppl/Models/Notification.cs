﻿namespace DonationAppl.Models
{

    public class Notification
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public string UserId { get; set; }
        public DateTime Timestamp { get; set; }

        public int AllocationId { get; set; }
        public Allocation Allocation { get; set; }
    }

}
