﻿namespace DonationAppl.Models
{
    public class Donation
        {
            public int DonationId { get; set; }
            public DateTime Date { get; set; }
            public decimal Amount { get; set; }
            public bool IsAnonymous { get; set; }

           
        

    }
}
