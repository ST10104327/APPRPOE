﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DonationAppl.Models
{
    public class Allocation
    {

        [Key]
        public int Id { get; set; }
        public int DisasterId { get; set; }
        public string UserId { get; set; }
        public string Status { get; set; }

        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Allocation amount must be non-negative.")]
        public decimal Amount { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime AllocationDate { get; set; }

        // Navigation properties for the related disaster and user
        public virtual Disaster Disaster { get; set; }
        public virtual ApplicationUser User { get; set; }
        public SelectList Disasters { get; internal set; }
    }

}


