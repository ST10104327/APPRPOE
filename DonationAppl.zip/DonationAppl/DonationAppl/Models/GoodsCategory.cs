﻿namespace DonationAppl.Models
{
    public class GoodsCategory
    {
      
            public int GoodsCategoryId { get; set; }
            public string Name { get; set; }

            
        }

    }

