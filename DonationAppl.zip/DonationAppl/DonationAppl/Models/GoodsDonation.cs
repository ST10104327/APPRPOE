﻿namespace DonationAppl.Models
{
    public class GoodsDonation
    {
        public int GoodsDonationId { get; set; }
        public DateTime Date { get; set; }
        public int NumberOfItems { get; set; }
        public string Description { get; set; }
        public bool IsAnonymous { get; set; }

        public int GoodsCategoryId { get; set; }
        public GoodsCategory GoodsCategory { get; set; }

    }
    }


